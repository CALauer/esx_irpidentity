Locales['en'] = {
  ['medical_center'] = 'Medical Center',
  ['press_to_switch'] = 'press ~INPUT_CONTEXT~ to ~b~switch characters~s~',

}
