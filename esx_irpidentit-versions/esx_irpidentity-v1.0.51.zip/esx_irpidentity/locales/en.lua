Locales['en'] = {
  ['press_to_switch'] = 'press ~g~E ~s~to ~b~switch characters~s~',
  ['spawn_location'] = 'Registration Center',
  ['Character3_exists'] = "You already 3 characters"
}
